from __future__ import print_function, division
import argparse
from loguru import logger as loguru_logger
import random
from core.Networks import build_network
import sys
sys.path.append('core')
from PIL import Image
import os
import numpy as np
import torch
from utils import flow_viz
from utils import frame_utils
from utils.utils import InputPadder, forward_interpolate
from inference import inference_core_skflow as inference_core
from configs.sintel_memflownet import get_cfg
import cv2


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


@torch.no_grad()
def inference(cfg, image1, image2):
    model = build_network(cfg).cuda()
    loguru_logger.info("Parameter Count: %d" % count_parameters(model))

    if cfg.restore_ckpt is not None:
        print("[Loading ckpt from {}]".format(cfg.restore_ckpt))
        ckpt = torch.load(cfg.restore_ckpt, map_location='cpu')
        ckpt_model = ckpt['model'] if 'model' in ckpt else ckpt
        if 'module' in list(ckpt_model.keys())[0]:
            for key in ckpt_model.keys():
                ckpt_model[key.replace('module.', '', 1)] = ckpt_model.pop(key)
            model.load_state_dict(ckpt_model, strict=True)
        else:
            model.load_state_dict(ckpt_model, strict=True)

    model.eval()

    print(f"preparing images...")

    # Zakładamy, że image1 i image2 to numpy arrays w formacie BGR (bo cv2.imread)
    # Zamiana BGR -> RGB
    img1 = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
    img2 = cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)

    # grayscale -> 3 kanały
    if len(img1.shape) == 2:
        img1 = np.tile(img1[..., None], (1, 1, 3))
    else:
        img1 = img1[..., :3]

    if len(img2.shape) == 2:
        img2 = np.tile(img2[..., None], (1, 1, 3))
    else:
        img2 = img2[..., :3]

    # Konwersja do tensora
    img1 = torch.from_numpy(img1).permute(2, 0, 1).float()
    img2 = torch.from_numpy(img2).permute(2, 0, 1).float()

    images = torch.stack([img1, img2])  # T=2

    processor = inference_core.InferenceCore(model, config=cfg)
    images = images.cuda().unsqueeze(0)  # 1, T, C, H, W

    padder = InputPadder(images.shape)
    images = padder.pad(images)

    images = 2 * (images / 255.0) - 1.0
    flow_prev = None
    results = []
    print(f"start inference...")

    for ti in range(images.shape[1] - 1):
        flow_low, flow_pre = processor.step(images[:, ti:ti + 2], end=(ti == images.shape[1] - 2),
                                            add_pe=('rope' in cfg and cfg.rope), flow_init=flow_prev)
        flow_pre = padder.unpad(flow_pre[0]).cpu()
        results.append(flow_pre)
        if 'warm_start' in cfg and cfg.warm_start:
            flow_prev = forward_interpolate(flow_low[0])[None].cuda()

    if not os.path.exists(cfg.vis_dir):
        os.makedirs(cfg.vis_dir)

    flow_img = flow_viz.flow_to_image(results[0].permute(1, 2, 0).numpy())
    image = Image.fromarray(flow_img)
    image.save('{}/flow_{:04}_to_{:04}.png'.format(cfg.vis_dir, 1, 2))

    return flow_img



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='MemFlowNet', choices=['MemFlowNet', 'MemFlowNet_T'], help="name your experiment")
    parser.add_argument('--restore_ckpt', help="restore checkpoint")
    parser.add_argument('--vis_dir', default='default')

    args = parser.parse_args()

    cfg = get_cfg()
    cfg.update(vars(args))

    # initialize random seed
    torch.manual_seed(1234)
    torch.cuda.manual_seed_all(1234)
    np.random.seed(1234)
    random.seed(1234)

    inference(cfg)
